-- فایل‌های پیوست هر جلسه (PDF، عکس و ...)
create table if not exists public.course_attachments (
  id uuid primary key default gen_random_uuid(),
  video_id uuid references public.course_videos(id) on delete cascade,
  title text not null,
  file_name text not null,
  file_size bigint,
  sort_order integer default 0,
  created_at timestamptz default now()
);
alter table public.course_attachments enable row level security;
create policy "attach_service" on public.course_attachments for all using (auth.role()='service_role') with check (auth.role()='service_role');
create policy "attach_admin" on public.course_attachments for all using (auth.role()='authenticated') with check (auth.role()='authenticated');
create index if not exists idx_attach_video on public.course_attachments(video_id);
select 'attachments table ready' as status;
