<?php
/**
 * آپلود ویدیوی معرفی دوره — عمومی و بدون نیاز به خرید
 * برخلاف ویدیوهای جلسات، این فایل مستقیم توی public_html ذخیره می‌شه
 */
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

require_once __DIR__ . '/api/config.php';

define('INTRO_DIR', __DIR__ . '/assets/intro');

function out($a, $c = 200) { http_response_code($c); echo json_encode($a, JSON_UNESCAPED_UNICODE); exit; }

$auth = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
$token = str_replace('Bearer ', '', $auth);
if (!$token) out(['ok'=>false,'error'=>'دسترسی غیرمجاز'], 401);

$ch = curl_init(SUPABASE_URL . '/auth/v1/user');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 15);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['apikey: '.getAnonKey(), 'Authorization: Bearer '.$token]);
$userRes = json_decode(curl_exec($ch), true);
curl_close($ch);
if (empty($userRes['id'])) out(['ok'=>false,'error'=>'توکن نامعتبر'], 401);

if (!is_dir(INTRO_DIR)) {
    if (!@mkdir(INTRO_DIR, 0755, true)) out(['ok'=>false,'error'=>'ساخت پوشه ناموفق'], 500);
}

if (empty($_FILES['file'])) out(['ok'=>false,'error'=>'فایلی ارسال نشد'], 400);

$f = $_FILES['file'];
if ($f['error'] !== UPLOAD_ERR_OK) {
    $errs = [1=>'حجم بیش از حد مجاز',2=>'حجم بیش از حد فرم',3=>'آپلود ناقص',4=>'فایلی انتخاب نشد',6=>'پوشه موقت یافت نشد',7=>'خطای نوشتن'];
    out(['ok'=>false,'error'=>isset($errs[$f['error']]) ? $errs[$f['error']] : 'خطای آپلود '.$f['error']], 400);
}

$ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
if (!in_array($ext, ['mp4','webm'])) out(['ok'=>false,'error'=>'فقط MP4 یا WebM'], 400);

$name = bin2hex(random_bytes(10)) . '.' . $ext;
$dest = INTRO_DIR . '/' . $name;

if (!move_uploaded_file($f['tmp_name'], $dest)) out(['ok'=>false,'error'=>'ذخیره فایل ناموفق'], 500);
@chmod($dest, 0644);

out(['ok'=>true, 'file_name'=>$name, 'url'=>'assets/intro/'.$name]);
