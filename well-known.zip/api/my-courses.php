<?php
/**
 * دوره‌های خریداری‌شده کاربر + ویدیوها
 */
require_once __DIR__ . '/config.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

$input = json_decode(file_get_contents('php://input'), true);
$phone = $input['phone'] ?? '';
$courseId = $input['course_id'] ?? null;

if (!preg_match('/^09\d{9}$/', $phone)) json_out(['ok' => false, 'error' => 'دسترسی نامعتبر'], 401);

$u = sb_request("academy_users?phone=eq.$phone&select=id,full_name");
$user = $u['data'][0] ?? null;
if (!$user) json_out(['ok' => false, 'error' => 'کاربر یافت نشد'], 404);

// لیست دوره‌های خریداری‌شده
$acc = sb_request("course_access?user_id=eq.{$user['id']}&is_active=eq.true&select=course_id,granted_at");
$accessList = $acc['data'] ?? [];

if (!$courseId) {
    $courses = [];
    foreach ($accessList as $a) {
        $c = sb_request("courses?id=eq.{$a['course_id']}&select=id,title,cover_url,level,duration");
        if (!empty($c['data'][0])) {
            $courses[] = array_merge($c['data'][0], ['granted_at' => $a['granted_at']]);
        }
    }
    json_out(['ok' => true, 'courses' => $courses]);
}

// ویدیوهای یک دوره خاص — فقط اگه دسترسی داره
$hasAccess = false;
foreach ($accessList as $a) if ($a['course_id'] === $courseId) $hasAccess = true;
if (!$hasAccess) json_out(['ok' => false, 'error' => 'شما به این دوره دسترسی ندارید'], 403);

$v = sb_request("course_videos?course_id=eq.$courseId&select=id,title,description,arvan_video_id,duration,sort_order&order=sort_order.asc");
json_out([
    'ok' => true,
    'videos' => $v['data'] ?? [],
    'watermark' => $phone,
    'user_name' => $user['full_name'] ?? '',
]);
