<?php
/**
 * کش داده‌های Supabase روی هاست ایرانی — نسخه‌ی سریع و پایدار
 *
 *  • همیشه فوراً از فایل محلی جواب می‌ده (بدون معطلی برای سرور خارجی)
 *  • اگه داده‌ها بیشتر از ۶۰ ثانیه قدیمی بودن، «بعد از ارسال جواب به کاربر» در پس‌زمینه تازه می‌شن
 *  • ?refresh=1 (از پنل ادمین) تازه‌سازی رو زودتر انجام می‌ده، ولی حداکثر هر ۵ ثانیه یک بار
 *  • این فایل هم مستقیم (به‌عنوان API) و هم از داخل index.php (به‌عنوان کتابخانه) استفاده می‌شه
 */

if (!function_exists('mm_cache_types')) {

    function mm_cache_types() {
        return [
    'projects' => 'projects?select=id,title,title_en,category,category_en,year,description,description_en,media_type,media_url,orientation,link,section,sort_order&order=sort_order.asc,created_at.desc',
    'courses' => 'courses?select=id,title,title_en,tag,tag_en,description,description_en,price,price_en,level,mode,duration,capacity,start_date,cover_url,video_url,intro_video_file,link,is_featured,sort_order,original_price_amount,discount_active,discount_label,discount_percent,slug&is_active=eq.true&order=sort_order.asc',
    'posts' => 'posts?select=id,title,title_en,slug,excerpt,excerpt_en,cover_url,video_url,category,category_en,is_featured,views,read_time,created_at&is_published=eq.true&order=created_at.desc&limit=50',
    'site_content' => 'site_content?select=key,value,value_en',
    'testimonials' => 'testimonials?select=id,name,role,course,content,avatar_url,rating,sort_order&is_published=eq.true&order=sort_order.asc,created_at.desc',
    'faqs' => 'faqs?select=id,question,answer,question_en,answer_en,sort_order&is_published=eq.true&order=sort_order.asc',
    'course_full' => 'courses?select=*&is_active=eq.true&order=sort_order.asc',
        ];
    }

    function mm_cache_dir() {
        return __DIR__ . '/cache';
    }

    function mm_cache_path($type) {
        return mm_cache_dir() . '/' . $type . '.json';
    }

    // سن فایل کش به ثانیه؛ اگه فایل نبود null
    function mm_cache_age($type) {
        $f = mm_cache_path($type);
        if (!is_file($f)) return null;
        $m = @filemtime($f);
        if ($m === false) return null;
        return time() - $m;
    }

    // محتوای کش به‌صورت آرایه؛ اگه نبود یا خراب بود null
    function mm_cache_read($type) {
        $f = mm_cache_path($type);
        if (!is_file($f)) return null;
        $raw = @file_get_contents($f);
        if ($raw === false || $raw === '') return null;
        $d = json_decode($raw, true);
        return is_array($d) ? $d : null;
    }

    // کلید anon رو خودکار از supabase-config.js می‌خونه
    function mm_anon_key() {
        static $key = null;
        if ($key !== null) return $key;
        $key = '';
        $cfg = dirname(__DIR__) . '/supabase-config.js';
        if (is_file($cfg)) {
            $c = @file_get_contents($cfg);
            if ($c && preg_match("/SUPABASE_ANON_KEY\s*=\s*['\"]([^'\"]+)['\"]/", $c, $m)) {
                $key = $m[1];
            }
        }
        return $key;
    }

    // تازه‌سازی یک نوع داده از Supabase؛ در صورت هر مشکلی کش قبلی دست‌نخورده می‌مونه
    function mm_cache_refresh($type) {
        $types = mm_cache_types();
        if (!isset($types[$type])) return false;
        $key = mm_anon_key();
        if ($key === '') return false;

        $dir = mm_cache_dir();
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        $file = mm_cache_path($type);

        // قفل نرم: زمان فایل رو همین الان به‌روز می‌کنیم تا درخواست‌های هم‌زمان دوباره سراغ Supabase نرن
        if (is_file($file)) @touch($file);

        $ch = curl_init('https://rknsiuyfhxnmhnfesfhh.supabase.co/rest/v1/' . $types[$type]);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 4,
            CURLOPT_TIMEOUT        => 8,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_ENCODING       => '',
            CURLOPT_HTTPHEADER     => ['apikey: ' . $key, 'Authorization: Bearer ' . $key],
        ]);
        $res  = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($code !== 200 || !is_string($res) || $res === '') return false;
        $d = json_decode($res, true);
        if (!is_array($d)) return false;

        $tmp = $file . '.' . getmypid() . '.tmp';
        if (@file_put_contents($tmp, $res) === false) return false;
        return @rename($tmp, $file);
    }

    // جواب رو به کاربر می‌فرسته و اتصال رو می‌بنده تا کارهای بعدی کاربر رو معطل نکنن
    function mm_cache_finish() {
        if (function_exists('litespeed_finish_request')) { litespeed_finish_request(); return true; }
        if (function_exists('fastcgi_finish_request'))   { fastcgi_finish_request();   return true; }
        return false;
    }
}

// وقتی از داخل index.php به‌عنوان کتابخانه لود می‌شه، همین‌جا تمومه
if (defined('MM_CACHE_LIB')) {
    return;
}

/* ════════════ حالت API ════════════ */
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: public, max-age=15');

$type  = isset($_GET['type']) ? $_GET['type'] : 'projects';
$types = mm_cache_types();
if (!isset($types[$type])) {
    http_response_code(400);
    echo json_encode(['error' => 'invalid type']);
    exit;
}

$ttl   = 60;
$force = isset($_GET['refresh']) && $_GET['refresh'] === '1';
$file  = mm_cache_path($type);
$age   = mm_cache_age($type);

if ($age === null) {
    // اولین بار است — چاره‌ای جز صبر کردن نیست
    mm_cache_refresh($type);
    $needs = false;
} else {
    $needs = ($age >= $ttl) || ($force && $age >= 5);
}

// اگه سرور اجازه‌ی «تازه‌سازی بعد از ارسال جواب» نمی‌ده، ناچاریم قبل از جواب تازه‌اش کنیم
$canDefer = function_exists('litespeed_finish_request') || function_exists('fastcgi_finish_request');
if ($needs && !$canDefer) {
    mm_cache_refresh($type);
    $needs = false;
}

$body = is_file($file) ? @file_get_contents($file) : false;
if ($body === false || $body === '') $body = '[]';
echo $body;

if ($needs) {
    mm_cache_finish();
    mm_cache_refresh($type);
}
