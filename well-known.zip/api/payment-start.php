<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

// خروجی امن حتی در صورت خطا
function out($arr, $code = 200) {
    http_response_code($code);
    echo json_encode($arr, JSON_UNESCAPED_UNICODE);
    exit;
}

// گرفتن هر خطای PHP
register_shutdown_function(function() {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        http_response_code(500);
        echo json_encode(['ok'=>false,'error'=>'FATAL: '.$e['message'].' @ '.basename($e['file']).':'.$e['line']], JSON_UNESCAPED_UNICODE);
    }
});

$cfg = __DIR__ . '/config.php';
if (!file_exists($cfg)) out(['ok'=>false,'error'=>'config.php یافت نشد'], 500);
require_once $cfg;

if (!defined('ZIBAL_MERCHANT') || ZIBAL_MERCHANT === 'PASTE_YOUR_ZIBAL_MERCHANT_HERE') {
    out(['ok'=>false,'error'=>'مرچنت زیبال تنظیم نشده'], 500);
}

$raw = file_get_contents('php://input');
$in = json_decode($raw, true);
if (!is_array($in)) out(['ok'=>false,'error'=>'ورودی نامعتبر'], 400);

$phone = trim($in['phone'] ?? '');
$courseId = trim($in['course_id'] ?? '');

if (!preg_match('/^09[0-9]{9}$/', $phone)) out(['ok'=>false,'error'=>'شماره موبایل نامعتبر'], 400);
if ($courseId === '') out(['ok'=>false,'error'=>'دوره مشخص نشده'], 400);

// کاربر
$u = sb_request('academy_users?phone=eq.' . rawurlencode($phone) . '&select=id,full_name,email');
if ($u['code'] !== 200) out(['ok'=>false,'error'=>'DB users: '.$u['code']], 500);
$user = isset($u['data'][0]) ? $u['data'][0] : null;
if (!$user) out(['ok'=>false,'error'=>'ابتدا وارد حساب کاربری شوید'], 401);
if (empty($user['full_name']) || empty($user['email'])) out(['ok'=>false,'error'=>'ابتدا پروفایل خود را تکمیل کنید','need_profile'=>true], 403);

// دوره
$c = sb_request('courses?id=eq.' . rawurlencode($courseId) . '&select=id,title,price_amount,is_active');
if ($c['code'] !== 200) out(['ok'=>false,'error'=>'DB courses: '.$c['code']], 500);
$course = isset($c['data'][0]) ? $c['data'][0] : null;
if (!$course) out(['ok'=>false,'error'=>'دوره یافت نشد'], 404);

$amount = (int)($course['price_amount'] ?? 0);
if ($amount < 1000) out(['ok'=>false,'error'=>'قیمت دوره تنظیم نشده'], 400);

// قبلاً خریده؟
$acc = sb_request('course_access?user_id=eq.'.rawurlencode($user['id']).'&course_id=eq.'.rawurlencode($courseId).'&is_active=eq.true&select=id');
if (!empty($acc['data'])) out(['ok'=>false,'error'=>'قبلاً خریداری شده','already_owned'=>true], 400);

// ثبت تراکنش
$pay = sb_request('payments', 'POST', [
    'user_id' => $user['id'],
    'course_id' => $courseId,
    'amount' => $amount,
    'status' => 'pending',
]);
$paymentId = isset($pay['data'][0]['id']) ? $pay['data'][0]['id'] : null;
if (!$paymentId) out(['ok'=>false,'error'=>'ثبت تراکنش ناموفق ('.$pay['code'].')','detail'=>$pay['data']], 500);

// زیبال
$payload = json_encode([
    'merchant' => ZIBAL_MERCHANT,
    'amount' => $amount * 10,
    'callbackUrl' => ZIBAL_CALLBACK,
    'description' => mb_substr($course['title'], 0, 50),
    'orderId' => $paymentId,
    'mobile' => $phone,
], JSON_UNESCAPED_UNICODE);

$ch = curl_init('https://gateway.zibal.ir/v1/request');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_TIMEOUT, 25);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
$zRaw = curl_exec($ch);
$zErr = curl_error($ch);
curl_close($ch);

if ($zErr) {
    sb_request('payments?id=eq.'.rawurlencode($paymentId), 'PATCH', ['status'=>'failed']);
    out(['ok'=>false,'error'=>'اتصال به زیبال: '.$zErr], 502);
}

$z = json_decode($zRaw, true);
if (!is_array($z)) {
    sb_request('payments?id=eq.'.rawurlencode($paymentId), 'PATCH', ['status'=>'failed']);
    out(['ok'=>false,'error'=>'پاسخ نامعتبر زیبال','raw'=>substr($zRaw,0,200)], 502);
}

$result = isset($z['result']) ? (int)$z['result'] : 0;
if ($result !== 100) {
    $m = [102=>'مرچنت یافت نشد',103=>'مرچنت غیرفعال',104=>'مرچنت نامعتبر',105=>'مبلغ کمتر از حد مجاز',106=>'آدرس بازگشت نامعتبر',113=>'مبلغ بیش از سقف'];
    $msg = isset($m[$result]) ? $m[$result] : (isset($z['message']) ? $z['message'] : 'خطای نامشخص');
    sb_request('payments?id=eq.'.rawurlencode($paymentId), 'PATCH', ['status'=>'failed']);
    out(['ok'=>false,'error'=>"زیبال ($result): $msg"], 502);
}

sb_request('payments?id=eq.'.rawurlencode($paymentId), 'PATCH', ['track_id'=>(string)$z['trackId']]);
out(['ok'=>true,'redirect'=>'https://gateway.zibal.ir/start/'.$z['trackId'],'track_id'=>$z['trackId']]);
