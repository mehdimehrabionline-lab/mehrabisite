<?php
/**
 * تأیید پرداخت بعد از بازگشت از زیبال
 */
require_once __DIR__ . '/config.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

$trackId = $_GET['trackId'] ?? $_POST['trackId'] ?? '';
if (!$trackId) {
    $input = json_decode(file_get_contents('php://input'), true);
    $trackId = $input['trackId'] ?? '';
}
if (!$trackId) json_out(['ok' => false, 'error' => 'شناسه تراکنش نامعتبر'], 400);

// تراکنش
$p = sb_request("payments?track_id=eq.$trackId&select=*");
$payment = $p['data'][0] ?? null;
if (!$payment) json_out(['ok' => false, 'error' => 'تراکنش یافت نشد'], 404);

if ($payment['status'] === 'paid') {
    json_out(['ok' => true, 'already' => true, 'course_id' => $payment['course_id']]);
}

// تأیید نزد زیبال
$ch = curl_init('https://gateway.zibal.ir/v1/verify');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_TIMEOUT => 20,
    CURLOPT_POSTFIELDS => json_encode([
        'merchant' => ZIBAL_MERCHANT,
        'trackId' => intval($trackId),
    ]),
]);
$res = json_decode(curl_exec($ch), true);
curl_close($ch);

$result = $res['result'] ?? 0;

// 100 = موفق، 201 = قبلاً تأیید شده
if ($result != 100 && $result != 201) {
    sb_request("payments?id=eq.{$payment['id']}", 'PATCH', ['status' => 'failed']);
    json_out(['ok' => false, 'error' => 'پرداخت ناموفق بود', 'code' => $result], 402);
}

// ثبت موفقیت
sb_request("payments?id=eq.{$payment['id']}", 'PATCH', [
    'status' => 'paid',
    'ref_number' => strval($res['refNumber'] ?? ''),
    'card_number' => $res['cardNumber'] ?? null,
    'paid_at' => gmdate('c'),
]);

// اعطای دسترسی
sb_request('course_access', 'POST', [
    'user_id' => $payment['user_id'],
    'course_id' => $payment['course_id'],
    'payment_id' => $payment['id'],
    'is_active' => true,
]);

// اطلاع به ادمین
$u = sb_request("academy_users?id=eq.{$payment['user_id']}&select=full_name,phone");
$c = sb_request("courses?id=eq.{$payment['course_id']}&select=title");
$uname = $u['data'][0]['full_name'] ?? 'نامشخص';
$uphone = $u['data'][0]['phone'] ?? '';
$ctitle = $c['data'][0]['title'] ?? 'دوره';
$amount = number_format($payment['amount']);

$msg = "💰 <b>خرید موفق!</b>\n\n👤 $uname\n📱 $uphone\n📚 $ctitle\n💵 $amount تومان\n🔖 کد پیگیری: " . ($res['refNumber'] ?? '-');

$notifyUrl = SUPABASE_URL . '/functions/v1/notify-admin';
$ch2 = curl_init($notifyUrl);
curl_setopt_array($ch2, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_TIMEOUT => 10,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_POSTFIELDS => json_encode(['text' => $msg], JSON_UNESCAPED_UNICODE),
]);
curl_exec($ch2);
curl_close($ch2);

json_out([
    'ok' => true,
    'course_id' => $payment['course_id'],
    'course_title' => $ctitle,
    'ref_number' => $res['refNumber'] ?? '',
    'amount' => $payment['amount'],
]);
