// ============================================================
//  پیکربندی Supabase — این مقادیر عمومی هستند و مشکلی ندارند
//  (امنیت واقعی توسط RLS در دیتابیس کنترل می‌شود)
// ============================================================
const SUPABASE_URL = 'https://rknsiuyfhxnmhnfesfhh.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJrbnNpdXlmaHhubWhuZmVzZmhoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA2ODA1OTcsImV4cCI6MjA5NjI1NjU5N30.pESi5RP_ZcrH5i07wK96LJgmUDDjagUKslftA83PTrw';

// ساخت کلاینت (کتابخانه از CDN لود می‌شود)
const sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
