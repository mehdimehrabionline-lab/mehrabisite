<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

$report = [];

// ۱. نسخه PHP
$report['php_version'] = PHP_VERSION;

// ۲. cURL موجوده؟
$report['curl'] = function_exists('curl_init') ? 'OK' : 'MISSING';

// ۳. فایل config
$configPath = __DIR__ . '/config.php';
$report['config_exists'] = file_exists($configPath);

if ($report['config_exists']) {
    require_once $configPath;
    $report['service_key'] = (defined('SERVICE_KEY') && SERVICE_KEY !== 'PASTE_YOUR_SERVICE_ROLE_KEY_HERE' && strlen(SERVICE_KEY) > 20) ? 'SET (' . strlen(SERVICE_KEY) . ' chars)' : 'NOT SET';
    $report['zibal_merchant'] = (defined('ZIBAL_MERCHANT') && ZIBAL_MERCHANT !== 'PASTE_YOUR_ZIBAL_MERCHANT_HERE') ? 'SET' : 'NOT SET';
    $report['anon_key'] = strlen(getAnonKey()) > 20 ? 'OK' : 'MISSING';

    // ۴. تست اتصال به Supabase
    $t = sb_request('courses?select=id,title,price_amount&limit=2');
    $report['supabase_code'] = $t['code'];
    $report['supabase_sample'] = $t['data'];

    // ۵. تست جداول جدید
    $p = sb_request('payments?select=id&limit=1');
    $report['payments_table'] = $p['code'] === 200 ? 'OK' : 'ERROR ' . $p['code'];
    $a = sb_request('course_access?select=id&limit=1');
    $report['course_access_table'] = $a['code'] === 200 ? 'OK' : 'ERROR ' . $a['code'];
    $v = sb_request('course_videos?select=id&limit=1');
    $report['course_videos_table'] = $v['code'] === 200 ? 'OK' : 'ERROR ' . $v['code'];
}

echo json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
