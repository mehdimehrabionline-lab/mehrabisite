-- ============================================================
--  به‌روزرسانی اطلاعات تماس در دیتابیس
--  یک‌بار در Supabase → SQL Editor → New query اجرا کن
-- ============================================================
insert into public.site_content (key, value) values
  ('contact_phone', '۰۹۱۷۰۰۷۳۰۱۰'),
  ('contact_email', 'mehdimehrabionline@gmail.com'),
  ('contact_instagram', 'Filmehdy')
on conflict (key) do update set value = excluded.value;
