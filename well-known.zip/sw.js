/*
 * Service Worker آکادمی مهدی محرابی — نسخه‌ی ایمن
 *
 * این فایل هیچ درخواستی رو رهگیری یا کش نمی‌کنه؛ همه‌ی صفحات، ویدیوها و API ها
 * مستقیم از اینترنت خونده می‌شن. فقط برای اینکه سایت روی گوشی «نصب‌شدنی» بمونه وجود داره.
 * نسخه‌های قبلی و همه‌ی کش‌هاشون به‌محض فعال شدن این نسخه پاک می‌شن.
 */
const SW_VERSION = 'safe-v2';

self.addEventListener('install', () => {
  // بلافاصله جای نسخه‌ی قبلی رو بگیر، بدون صبر برای بسته شدن تب‌ها
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    // پاک کردن همه‌ی کش‌های نسخه‌های قبلی
    const keys = await caches.keys();
    await Promise.all(keys.map((k) => caches.delete(k)));
    await self.clients.claim();
  })());
});

// عمداً هیچ respondWith() صدا زده نمی‌شه → مرورگر هر درخواست رو عادی و مستقیم انجام می‌ده
// (همین باعث می‌شه دیگه هیچ‌وقت خطای ERR_FAILED از سمت Service Worker پیش نیاد)
self.addEventListener('fetch', () => {});
