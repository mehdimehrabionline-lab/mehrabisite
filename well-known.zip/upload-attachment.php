<?php
/**
 * آپلود فایل پیوست جلسه (PDF، عکس و ...) — فقط برای ادمین
 */
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

require_once __DIR__ . '/api/config.php';

define('ATTACH_DIR', dirname(__DIR__) . '/protected_videos');

function out($a, $c = 200) { http_response_code($c); echo json_encode($a, JSON_UNESCAPED_UNICODE); exit; }

$auth = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
$token = str_replace('Bearer ', '', $auth);
if (!$token) out(['ok'=>false,'error'=>'دسترسی غیرمجاز'], 401);

$ch = curl_init(SUPABASE_URL . '/auth/v1/user');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 15);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['apikey: '.getAnonKey(), 'Authorization: Bearer '.$token]);
$userRes = json_decode(curl_exec($ch), true);
curl_close($ch);
if (empty($userRes['id'])) out(['ok'=>false,'error'=>'توکن نامعتبر'], 401);

if (!is_dir(ATTACH_DIR)) {
    if (!@mkdir(ATTACH_DIR, 0750, true)) out(['ok'=>false,'error'=>'ساخت پوشه ناموفق — دستی بسازید: '.ATTACH_DIR], 500);
}

if (empty($_FILES['file'])) out(['ok'=>false,'error'=>'فایلی ارسال نشد'], 400);

$f = $_FILES['file'];
if ($f['error'] !== UPLOAD_ERR_OK) {
    $errs = [1=>'حجم بیش از حد مجاز PHP',2=>'حجم بیش از حد فرم',3=>'آپلود ناقص',4=>'فایلی انتخاب نشد',6=>'پوشه موقت یافت نشد',7=>'خطای نوشتن'];
    out(['ok'=>false,'error'=>isset($errs[$f['error']]) ? $errs[$f['error']] : 'خطای آپلود '.$f['error']], 400);
}

$ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
if (!in_array($ext, ['pdf','jpg','jpeg','png','webp','zip','doc','docx','ppt','pptx'])) {
    out(['ok'=>false,'error'=>'فرمت مجاز: PDF, عکس, ZIP, Word, PowerPoint'], 400);
}

$name = bin2hex(random_bytes(12)) . '.' . $ext;
$dest = ATTACH_DIR . '/' . $name;

if (!move_uploaded_file($f['tmp_name'], $dest)) out(['ok'=>false,'error'=>'ذخیره فایل ناموفق'], 500);
@chmod($dest, 0640);

out(['ok'=>true, 'file_name'=>$name, 'size'=>filesize($dest)]);
