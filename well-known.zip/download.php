<?php
/**
 * دانلود امن فایل پیوست
 */
require_once __DIR__ . '/api/config.php';

define('ATTACH_DIR', dirname(__DIR__) . '/protected_videos');

$token = isset($_GET['t']) ? $_GET['t'] : '';
if (!$token) { http_response_code(403); exit('Forbidden'); }

$parts = explode('.', $token);
if (count($parts) !== 2) { http_response_code(403); exit('Invalid'); }
if (!hash_equals(hash_hmac('sha256', $parts[0], SERVICE_KEY), $parts[1])) { http_response_code(403); exit('Bad signature'); }

$payload = json_decode(base64_decode(strtr($parts[0], '-_', '+/')), true);
if (!is_array($payload) || !isset($payload['exp']) || $payload['exp'] < time()) { http_response_code(403); exit('Expired'); }

$file = isset($payload['f']) ? basename($payload['f']) : '';
$path = ATTACH_DIR . '/' . $file;
if (!$file || !file_exists($path)) { http_response_code(404); exit('Not found'); }

$ref = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
if ($ref && stripos($ref, 'mehdimehrabi.ir') === false) { http_response_code(403); exit('Hotlink denied'); }

$ext = pathinfo($path, PATHINFO_EXTENSION);
$title = isset($payload['title']) ? $payload['title'] : 'file';
$safeTitle = preg_replace('/[^\p{L}\p{N}\s_-]/u', '', $title);
$downloadName = $safeTitle . '.' . $ext;

$mimes = ['pdf'=>'application/pdf','jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','zip'=>'application/zip','doc'=>'application/msword','docx'=>'application/vnd.openxmlformats-officedocument.wordprocessingml.document','ppt'=>'application/vnd.ms-powerpoint','pptx'=>'application/vnd.openxmlformats-officedocument.presentationml.presentation'];
$mime = isset($mimes[strtolower($ext)]) ? $mimes[strtolower($ext)] : 'application/octet-stream';

header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($path));
header('Content-Disposition: attachment; filename="' . $downloadName . '"');
header('X-Content-Type-Options: nosniff');
readfile($path);
