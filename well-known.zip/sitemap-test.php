<?php
header('Content-Type: text/plain; charset=utf-8');

echo "=== تست اتصال sitemap ===\n\n";

$cfg = __DIR__ . '/supabase-config.js';
echo "1. فایل supabase-config.js: " . (file_exists($cfg) ? "پیدا شد ✓" : "پیدا نشد ✗") . "\n";

$ANON_KEY = '';
if (file_exists($cfg)) {
    $content = file_get_contents($cfg);
    if (preg_match("/SUPABASE_ANON_KEY\s*=\s*['\"]([^'\"]+)['\"]/", $content, $m)) {
        $ANON_KEY = $m[1];
        echo "2. کلید anon: پیدا شد ✓ (" . strlen($ANON_KEY) . " کاراکتر)\n";
    } else {
        echo "2. کلید anon: پیدا نشد ✗\n";
        echo "   محتوای فایل:\n   " . substr($content, 0, 300) . "\n";
    }
}

echo "3. تابع curl: " . (function_exists('curl_init') ? "موجود ✓" : "موجود نیست ✗") . "\n\n";

if ($ANON_KEY) {
    $url = 'https://rknsiuyfhxnmhnfesfhh.supabase.co/rest/v1/courses?select=id,slug,title&is_active=eq.true';
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER => ['apikey: ' . $ANON_KEY, 'Authorization: Bearer ' . $ANON_KEY],
    ]);
    $res = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);

    echo "4. درخواست به Supabase:\n";
    echo "   کد HTTP: $code\n";
    if ($err) echo "   خطای curl: $err\n";
    echo "   پاسخ:\n";
    $d = json_decode($res, true);
    if (is_array($d)) {
        echo "   تعداد دوره‌ها: " . count($d) . "\n";
        foreach ($d as $c) {
            echo "   - " . ($c['title'] ?? '?') . " → slug: " . ($c['slug'] ?? 'خالی') . "\n";
        }
    } else {
        echo "   " . substr($res, 0, 500) . "\n";
    }
}
