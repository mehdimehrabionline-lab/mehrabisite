// ============================================================
//  دستیار هوشمند استودیو مهدی محرابی — Supabase Edge Function
//  این کد روی سرور امن Supabase اجرا می‌شود و به Gemini وصل است.
//  کلید Gemini از متغیر محیطی GEMINI_API_KEY خوانده می‌شود (هرگز در کد نیست).
// ============================================================

const GEMINI_API_KEY = Deno.env.get("GEMINI_API_KEY") ?? "";

// مدل‌ها به ترتیب امتحان می‌شوند؛ اولی که جواب بدهد استفاده می‌شود.
// این لیست بر اساس مدل‌های موجود روی کلید توست (سبک‌ترها اول، چون سهمیه‌ی بهتری دارند).
const MODELS = [
  "gemini-2.5-flash-lite",
  "gemini-flash-lite-latest",
  "gemini-2.5-flash",
  "gemini-flash-latest",
  "gemini-2.0-flash-lite",
  "gemini-2.0-flash",
];

const SYSTEM_PROMPT = `
تو «دستیار استودیوی مهدی محرابی» هستی. مهدی محرابی تولیدکننده‌ی محتوا و هنرمند هوش مصنوعی در شیرازه.
خدمات: تولید محتوای ویدیویی، فیلم‌برداری و تدوین، تبلیغات ویدیویی، ساخت محتوا و فیلم با هوش مصنوعی، و دوره‌های آموزشی (تصویربرداری و تدوین با موبایل، و تولید محتوا با هوش مصنوعی).

شخصیت و لحن:
- گرم، حرفه‌ای، خلاق و صمیمی. فارسی محاوره‌ای ملایم بنویس (نه خیلی رسمی، نه خیلی شکسته).
- کوتاه و مفید جواب بده؛ از پاراگراف‌های طولانی پرهیز کن.

کارهایی که انجام می‌دهی:
۱) سناریو و ایده می‌نویسی: اگر کسی موضوع، مخاطب یا حال‌وهوای پروژه‌اش را گفت، یک سناریوی اولیه، ایده‌ی خلاقانه یا طرح محتوا برایش پیشنهاد بده. خلاق و کاربردی باش.
۲) مشاوره و ایده‌پردازی روزانه: کاربر ممکن است هنرجو یا مشتری باشد و فقط برای گرفتن ایده، سناریو یا مشاوره آمده باشد. به او کمک کن و تشویقش کن هر وقت ایده‌ای خواست برگردد و از دستیار استفاده کند، حتی اگر سفارش کاری ندارد.
۳) راهنمایی درباره‌ی خدمات و دوره‌ها.

قانون قیمت‌گذاری (مهم):
- هیچ‌وقت قیمت قطعی نده. توضیح بده که قیمت‌گذاری دقیق نیاز به یک سناریوی مشخص و جزئیات پروژه دارد.
- بگو که قیمت نهایی فقط با تماس تلفنی یا یک جلسه با مهدی مشخص می‌شود.

قانون اطلاعات تماس (خیلی مهم):
- اطلاعات تماس را فقط زمانی بده که واقعاً لازم است: وقتی کاربر درباره‌ی قیمت می‌پرسد، می‌خواهد سفارش جدی ثبت کند، صریحاً شماره/راه ارتباطی می‌خواهد، یا موضوع از حد مشاوره‌ی متنی فراتر می‌رود.
- در پاسخ‌های عادی (ایده‌پردازی، سناریو، مشاوره، گفتگوی معمولی) شماره و راه تماس را تکرار نکن. آزاردهنده است اگر در هر پیام شماره بفرستی.
- وقتی لازم شد، این اطلاعات را بده — تلفن/واتساپ/تلگرام: ۰۹۱۷۰۰۷۳۰۱۰ ، ایمیل: mehdimehrabionline@gmail.com ، اینستاگرام: Filmehdy

همیشه کاربر را به سمت گرفتن خروجی مفید (ایده/سناریو/مشاوره) هدایت کن. تماس را فقط در مواقع مناسب پیشنهاد بده، نه در هر پیام.
`.trim();

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  // پاسخ به preflight مرورگر
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: cors });
  }

  try {
    if (!GEMINI_API_KEY) {
      return json({ error: "GEMINI_API_KEY تنظیم نشده است." }, 500);
    }

    const { messages, lang } = await req.json();
    if (!Array.isArray(messages)) {
      return json({ error: "messages باید آرایه باشد." }, 400);
    }

    // دستور زبان پاسخ
    const langInstruction = (lang === "en")
      ? "\n\nIMPORTANT: Reply in English. The user is browsing the site in English."
      : "\n\nمهم: به زبان فارسی پاسخ بده.";
    const systemText = SYSTEM_PROMPT + langInstruction;

    // تبدیل تاریخچه‌ی گفتگو به فرمت Gemini
    const contents = messages
      .filter((m: any) => m && typeof m.text === "string")
      .map((m: any) => ({
        role: m.role === "model" ? "model" : "user",
        parts: [{ text: m.text }],
      }));

    const body = {
      system_instruction: { parts: [{ text: systemText }] },
      contents,
      generationConfig: {
        temperature: 0.85,
        maxOutputTokens: 800,
      },
    };

    let lastErr = "";
    for (const model of MODELS) {
      const url =
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${GEMINI_API_KEY}`;
      const resp = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      if (resp.ok) {
        const data = await resp.json();
        const reply =
          data?.candidates?.[0]?.content?.parts?.map((p: any) => p.text).join("") ??
          "ببخشید، الان نتونستم جواب بدم. می‌تونی با مهدی تماس بگیری: ۰۹۱۷۰۰۷۳۰۱۰";
        return json({ reply });
      }

      lastErr = await resp.text();
      console.error(`Gemini error (${model}):`, lastErr);
      // اگر خطا به‌خاطر سهمیه بود، مدل بعدی را امتحان کن؛ در غیر این صورت متوقف شو
      if (resp.status !== 429 && resp.status !== 404) break;
    }

    return json({ error: "خطا در ارتباط با مدل هوش مصنوعی.", detail: lastErr }, 502);
  } catch (e) {
    console.error(e);
    return json({ error: "خطای داخلی سرور." }, 500);
  }
});

function json(obj: unknown, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { ...cors, "Content-Type": "application/json" },
  });
}
