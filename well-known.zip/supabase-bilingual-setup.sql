-- ============================================================
--  افزودن ستون‌های انگلیسی برای دوزبانه‌کردن سایت
--  یک‌بار در Supabase → SQL Editor → New query اجرا کن
-- ============================================================

-- متن‌های سایت: یک ستون انگلیسی
alter table public.site_content add column if not exists value_en text;

-- نمونه‌کارها: عنوان، دسته و توضیح انگلیسی
alter table public.projects add column if not exists title_en text;
alter table public.projects add column if not exists category_en text;
alter table public.projects add column if not exists description_en text;

-- دوره‌ها: عنوان، برچسب، توضیح و متن دکمه‌ی انگلیسی
-- (اگر هنوز جدول courses را نساخته‌ای، اول supabase-courses-setup.sql را اجرا کن)
alter table public.courses add column if not exists title_en text;
alter table public.courses add column if not exists tag_en text;
alter table public.courses add column if not exists description_en text;
alter table public.courses add column if not exists cta_en text;
