<?php
/**
 * ارسال پیامک «خرید موفق» وقتی ادمین دستی به کسی دسترسی دوره می‌ده
 */
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

require_once __DIR__ . '/api/config.php';

// نام دوره برای پیامک — SMS.ir حداکثر ۲۵ کاراکتر برای هر پارامتر قبول می‌کنه
if (!function_exists('sms_course_name')) {
function sms_course_name($title, $short = '') {
    $short = trim((string)$short);
    if ($short !== '') return mb_substr($short, 0, 25);
    $t = trim(preg_replace('/^دوره\s+/u', '', trim((string)$title)));
    if ($t === '') $t = 'دوره آموزشی';
    if (mb_strlen($t) <= 25) return $t;
    $cut = mb_substr($t, 0, 24);
    $sp = mb_strrpos($cut, ' ');
    if ($sp !== false && $sp > 10) $cut = mb_substr($cut, 0, $sp);
    return $cut . '…';
}
}


function out($a, $c = 200) { http_response_code($c); echo json_encode($a, JSON_UNESCAPED_UNICODE); exit; }

// فقط ادمین (توکن Supabase Auth) اجازه داره این رو صدا بزنه
$auth = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
$token = str_replace('Bearer ', '', $auth);
if (!$token) out(['ok'=>false,'error'=>'دسترسی غیرمجاز'], 401);
$ch = curl_init(SUPABASE_URL . '/auth/v1/user');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 15);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['apikey: '.getAnonKey(), 'Authorization: Bearer '.$token]);
$userRes = json_decode(curl_exec($ch), true);
curl_close($ch);
if (empty($userRes['id'])) out(['ok'=>false,'error'=>'توکن نامعتبر'], 401);

$body = json_decode(file_get_contents('php://input'), true);
$phone = isset($body['phone']) ? trim($body['phone']) : '';
$courseTitle = isset($body['course_title']) ? trim($body['course_title']) : 'دوره';
$courseSms = isset($body['sms_title']) ? trim($body['sms_title']) : '';

if (!preg_match('/^09[0-9]{9}$/', $phone)) out(['ok'=>false,'error'=>'شماره نامعتبر'], 400);

if (!defined('SMSIR_KEY') || SMSIR_KEY === '') out(['ok'=>false,'error'=>'SMSIR_KEY تنظیم نشده']);

// کد پیگیری خودکار برای دسترسی دستی: yymmdd + ۴ رقم تصادفی (مثلاً ۲۶۰۹۲۵۴۸۱۷)
$orderId = date('ymd') . str_pad((string)random_int(0, 9999), 4, '0', STR_PAD_LEFT);

$smsBody = json_encode([
    'mobile' => preg_replace('/^0/', '98', $phone),
    'templateId' => 869916,
    'parameters' => [
        ['name' => 'ORDERID', 'value' => $orderId],
    ],
], JSON_UNESCAPED_UNICODE);

$chSms = curl_init('https://api.sms.ir/v1/send/verify');
curl_setopt($chSms, CURLOPT_RETURNTRANSFER, true);
curl_setopt($chSms, CURLOPT_POST, true);
curl_setopt($chSms, CURLOPT_TIMEOUT, 15);
curl_setopt($chSms, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($chSms, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'X-API-KEY: ' . SMSIR_KEY]);
curl_setopt($chSms, CURLOPT_POSTFIELDS, $smsBody);
$res = curl_exec($chSms);
curl_close($chSms);

out(['ok'=>true, 'message'=>'پیامک ارسال شد', 'order_id'=>$orderId]);
