<?php
header('Content-Type: text/plain; charset=utf-8');
echo "=== تست بازنویسی آدرس ===\n\n";
echo "REQUEST_URI: " . ($_SERVER['REQUEST_URI'] ?? '-') . "\n";
echo "QUERY_STRING: " . ($_SERVER['QUERY_STRING'] ?? '-') . "\n";
echo "پارامتر slug: " . ($_GET['slug'] ?? '(خالی)') . "\n\n";
if (!empty($_GET['slug'])) {
    echo "✓ بازنویسی کار می‌کند!\n";
} else {
    echo "✗ بازنویسی کار نمی‌کند یا slug فرستاده نشده\n";
}
